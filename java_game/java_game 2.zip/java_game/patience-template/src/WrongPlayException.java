
public class WrongPlayException extends Exception {
    public WrongPlayException(String error){
        super(error);
    }
}
